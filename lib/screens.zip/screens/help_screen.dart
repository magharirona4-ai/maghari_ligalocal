import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../theme.dart';
import '../widgets.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  static const _items = [
    (Icons.help_outline, 'FAQs', 'Find answers to common questions'),
    (Icons.mail_outline, 'Contact Us', 'Get in touch with our support team'),
    (Icons.error_outline, 'Report a Problem', 'Help us improve the app'),
    (Icons.article_outlined, 'Terms & Conditions', 'Read our terms and conditions'),
    (Icons.privacy_tip_outlined, 'Privacy Policy', 'How we handle your data'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Long-press the title to open the About screen (it has no button in Figma).
      appBar: navyAppBar(context, 'Help & Support',
          fallback: '/more', onTitleLongPress: () => context.push('/about')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        for (final i in _items)
          AppCard(
            borderColor: C.border,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
            onTap: () => ScaffoldMessenger.of(context)
                .showSnackBar(const SnackBar(content: Text('Coming soon'))),
            child: Row(children: [
              Icon(i.$1, size: 16, color: C.navy),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(i.$2,
                      style: const TextStyle(
                          color: C.navy, fontSize: 11, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(i.$3, style: const TextStyle(color: C.grey, fontSize: 9)),
                ]),
              ),
              const Icon(Icons.chevron_right, size: 18, color: C.grey),
            ]),
          ),
      ]),
    );
  }
}
