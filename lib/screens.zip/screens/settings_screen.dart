import 'package:flutter/material.dart';
import '../theme.dart';
import '../widgets.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notifications = true;

  void _soon() => ScaffoldMessenger.of(context)
      .showSnackBar(const SnackBar(content: Text('Coming soon')));

  Widget _row(IconData icon, String label, {String? value, Widget? trailing}) =>
      AppCard(
        borderColor: C.border,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 18),
        onTap: trailing == null ? _soon : null,
        child: Row(children: [
          Icon(icon, size: 16, color: C.navy),
          const SizedBox(width: 14),
          Expanded(
            child: Text(label,
                style: const TextStyle(
                    color: C.navy, fontSize: 12, fontWeight: FontWeight.w700)),
          ),
          if (value != null)
            Text(value, style: const TextStyle(color: C.grey, fontSize: 10)),
          trailing ?? const Icon(Icons.chevron_right, size: 18, color: C.grey),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: navyAppBar(context, 'Settings', fallback: '/more'),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _row(Icons.lock_outline, 'Change Password'),
        _row(
          Icons.notifications_none,
          'Notifications',
          trailing: Switch(
            value: _notifications,
            activeThumbColor: Colors.white,
            activeTrackColor: C.orange,
            onChanged: (v) => setState(() => _notifications = v),
          ),
        ),
        _row(Icons.language, 'Language', value: 'English'),
        _row(Icons.contrast, 'Theme', value: 'Dark'),
        _row(Icons.delete_outline, 'Clear Cache', value: '56.4 MB'),
      ]),
    );
  }
}
