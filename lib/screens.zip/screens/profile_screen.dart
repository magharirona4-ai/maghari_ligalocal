import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../auth_state.dart';
import '../theme.dart';
import '../widgets.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _soon(BuildContext context) => ScaffoldMessenger.of(context)
      .showSnackBar(const SnackBar(content: Text('Coming soon')));

  Widget _item(IconData icon, String label, VoidCallback onTap) => AppCard(
        borderColor: C.border,
        margin: const EdgeInsets.only(bottom: 2),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
        onTap: onTap,
        child: Row(children: [
          Icon(icon, size: 16, color: C.navy),
          const SizedBox(width: 14),
          Expanded(
            child: Text(label,
                style: const TextStyle(
                    color: C.navy, fontSize: 12, fontWeight: FontWeight.w700)),
          ),
          const Icon(Icons.chevron_right, size: 18, color: C.grey),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: auth,
      builder: (context, _) => Scaffold(
        appBar: navyAppBar(context, 'Profile'),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          AppCard(
            borderColor: C.border,
            padding: const EdgeInsets.all(18),
            margin: const EdgeInsets.only(bottom: 14),
            child: Row(children: [
              const CircleAvatar(radius: 16, backgroundColor: C.navy),
              const SizedBox(width: 18),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(auth.fullName.isEmpty ? 'Your name' : auth.fullName,
                      style: const TextStyle(
                          color: C.navy, fontSize: 14, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(auth.email,
                      style: const TextStyle(color: C.grey, fontSize: 10)),
                  const SizedBox(height: 4),
                  Text(
                      auth.isOrganizer
                          ? 'Organizer account'
                          : (auth.organizerPending
                              ? 'Player account • Organizer request pending'
                              : 'Player account'),
                      style: const TextStyle(
                          color: C.green, fontSize: 10, fontWeight: FontWeight.w700)),
                ]),
              ),
            ]),
          ),
          if (auth.isOrganizer)
            _item(Icons.admin_panel_settings_outlined, 'Organizer Panel',
                () => context.push('/organizer')),
          _item(Icons.person, 'My Profile', () => _soon(context)),
          _item(Icons.person, 'My Teams', () => context.push('/more/my-teams')),
          _item(Icons.notifications_none, 'Notifications',
              () => context.push('/more/settings')),
          _item(Icons.lock_outline, 'Privacy & Security', () => _soon(context)),
          _item(Icons.help_outline, 'Help & Support', () => context.push('/more/help')),
          const SizedBox(height: 22),
          SizedBox(
            height: 44,
            child: OutlinedButton(
              onPressed: auth.logout,
              style: OutlinedButton.styleFrom(
                backgroundColor: Colors.white,
                side: const BorderSide(color: C.red),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('Log Out',
                  style: TextStyle(
                      color: C.red, fontSize: 12, fontWeight: FontWeight.w700)),
            ),
          ),
        ]),
      ),
    );
  }
}
